# phpBB-searchreload
makes 'unread posts' and similar views of search.php reload every 120 seconds
